package com.example.SpringReact.models;

public class Student
{

}
