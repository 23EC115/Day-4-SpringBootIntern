package com.example.SpringReact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringReact {
	public static void main(String[] args) {
		SpringReact s=(SpringReact)SpringApplication.run(SpringReact.class, args);
	}

}
